/* No thread support. */

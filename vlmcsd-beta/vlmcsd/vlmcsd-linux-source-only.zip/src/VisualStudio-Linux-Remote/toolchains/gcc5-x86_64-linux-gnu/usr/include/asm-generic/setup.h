#ifndef __ASM_GENERIC_SETUP_H
#define __ASM_GENERIC_SETUP_H

#define COMMAND_LINE_SIZE	512

#endif	/* __ASM_GENERIC_SETUP_H */

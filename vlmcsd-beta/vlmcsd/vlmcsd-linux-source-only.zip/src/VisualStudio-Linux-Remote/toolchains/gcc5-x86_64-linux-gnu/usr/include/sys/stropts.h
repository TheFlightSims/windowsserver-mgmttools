#include <stropts.h>
